import { Component, OnInit } from '@angular/core';
@Component({
 selector : 'au-distrbutor',
 templateUrl : './distributorhome.component.html',
})
export class DistributorHomeComponent implements OnInit
{
    ngOnInit(){}
}