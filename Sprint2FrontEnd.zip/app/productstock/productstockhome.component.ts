import { Component, OnInit } from '@angular/core';
@Component
({
	selector : 'productstockhome',
	templateUrl : './productstockhome.component.html'
})
export class ProductStockHomeComponent implements OnInit
{
    ngOnInit(){}
}