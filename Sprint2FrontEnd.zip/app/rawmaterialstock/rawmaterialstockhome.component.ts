import { Component, OnInit } from '@angular/core';
@Component
({
	selector : 'rawmaterialstockhome',
	templateUrl : './rawmaterialstockhome.component.html'
})
export class RawMaterialStockHomeComponent implements OnInit
{
    ngOnInit(){}
}