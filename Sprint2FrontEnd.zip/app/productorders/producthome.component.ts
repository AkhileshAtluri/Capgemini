import { Component, OnInit } from '@angular/core';


@Component({

  selector: 'producthome',

  templateUrl: './producthome.component.html',

  
})

export class ProductHomeComponent implements OnInit
{
  
	ngOnInit() {}
}
