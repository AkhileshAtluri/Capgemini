package com.cg.anurag.b4.distributor.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.anurag.b4.distributor.dto.Distributor;
@Repository
public interface DistributorDAO extends JpaRepository<Distributor,Integer> {

}
