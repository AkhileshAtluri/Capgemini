package com.cg.anurag.b4.distributor.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.anurag.b4.distributor.dto.Distributor;
import com.cg.anurag.b4.distributor.service.DistributorService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class DistributorController
{

    @Autowired
	DistributorService  distributorService;
	public void setDistributorService(DistributorService distributorService)
	{
		this.distributorService=distributorService;
	}
	
   @GetMapping(value = "/getDistributor/{distributorId}")
   public Distributor getDistributor(@PathVariable int distributorId)
   {
	   return distributorService.getDistributor(distributorId);
   }
   
   @GetMapping(value = "/getDistributors")
   public List<Distributor> getDistributor()
   {
	   return distributorService.getDistributor();
   }
   @PostMapping(value="/addDistributor",consumes="application/json")
   public ResponseEntity<String> insertDistributor(@RequestBody()Distributor distributor)
   {
	   String message="Distributor Inserted Successfully";
	   if(distributorService.insertDistributor(distributor)==null)
		   message="Distributor Insertion Failed";
	   return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
   }
   
   @PutMapping(value="/updateDistributor",consumes="application/json")
   public String updateDistributor(@RequestBody()Distributor distributor)
   {
	   String message=distributorService.updateDistributor(distributor);
	   return message;
   }
}