package com.cg.anurag.rawmaterialstock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RawMaterialStockServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
