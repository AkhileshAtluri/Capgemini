package com.cg.anurag.b4.products.dto;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="products")
public class Product 
{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="MYSEQ")
	@SequenceGenerator(name="MYSEQ",sequenceName = "productid",allocationSize=1)
	@Column(name="productid")
	int productId;
	@Column(name="productname")
	String productName;
	@Column(name="priceperunit")
	int pricePerUnit;
	@Column(name="productdesc")
	String description;
	@Column(name="warehouseid")
	int wareHouseId;
	@Column(name="distributorid")
	int distributorId;
	@Column(name="manufacturingdate")
	LocalDate manufacturingDate;
	@Column(name="expirydate")
	LocalDate expiryDate;
	public Product() {}
	public Product(int productId, String productName, int pricePerUnit, String description,
			int wareHouseId, int distributorId, LocalDate manufacturingDate,
			LocalDate expiryDate) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.pricePerUnit = pricePerUnit;
		this.description = description;
		this.wareHouseId = wareHouseId;
		this.distributorId = distributorId;
		this.manufacturingDate = manufacturingDate;
		this.expiryDate = expiryDate;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getPricePerUnit() {
		return pricePerUnit;
	}

	public void setPricePerUnit(int pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	public String getDescription() {
		return description;
	}

	public void setdescription(String description) {
		this.description = description;
	}

	public int getWareHouseId() {
		return wareHouseId;
	}

	public void setWareHouseId(int wareHouseId) {
		this.wareHouseId = wareHouseId;
	}

	public int getDistributorId() {
		return distributorId;
	}

	public void setDistributorId(int distributorId) {
		this.distributorId = distributorId;
	}

	public LocalDate getManufacturingDate() {
		return manufacturingDate;
	}

	public void setManufacturingDate(LocalDate manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	
}