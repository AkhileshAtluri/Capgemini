package com.cg.anurag.b4.products.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.anurag.b4.products.dao.ProductDAO;
import com.cg.anurag.b4.products.dto.Product;



@Service
public class ProductService {

	@Autowired 
	private ProductDAO productDao;
	public void setProductDao(ProductDAO productDao) { this.productDao=productDao;}
	public List<Product>  viewProduct() {
		// TODO Auto-generated method stub
		return productDao.findAll();
	}


}
