package com.cg.anurag.b4.products.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.anurag.b4.products.dto.Product;



@Repository
public interface ProductDAO extends JpaRepository<Product,String> 
{
	public Optional<Product> findByProductId(String ProductId);

}
