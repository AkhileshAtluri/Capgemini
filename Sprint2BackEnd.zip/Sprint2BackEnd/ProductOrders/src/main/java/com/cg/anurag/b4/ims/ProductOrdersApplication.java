package com.cg.anurag.b4.ims;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class ProductOrdersApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductOrdersApplication.class, args);
	}

}
