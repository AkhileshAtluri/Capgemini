package com.cg.anurag.b4.ims.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.anurag.b4.ims.dao.ProductsDAO;
import com.cg.anurag.b4.ims.dto.Products;
@Service
public class ProductsService 
{
	@Autowired
	ProductsDAO pdsdao;
	public void setPdsmdao(ProductsDAO pdsdao) 
	{
		this.pdsdao = pdsdao;
	}
	@Transactional
	public Products getProductById(int productId)
	{
		return pdsdao.findById(productId).get();
	}
	@Transactional
	public List<Products> getProductsList()
	{
		return pdsdao.findAll();
	}
}
