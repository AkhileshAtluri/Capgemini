package com.cg.anurag.b4.ims.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.anurag.b4.ims.dao.DistributorDAO;
import com.cg.anurag.b4.ims.dto.Distributor;
@Service
public class DistributorService {
	 @Autowired
	    DistributorDAO Ddao;
	    public void setBdao(DistributorDAO ddao) { this.Ddao=ddao;}
	    @Transactional
	    public Distributor insertDistributor(Distributor distributor)
	    {
	        return Ddao.save(distributor);
	    }
	    @Transactional(readOnly=true)
	    public Distributor getDistributor(int distributorId)
	    {
	    	return Ddao.findById(distributorId).get();
	    }
	    @Transactional(readOnly=true)
	    public List<Distributor> getDistributor()
	    {
	    	return Ddao.findAll();
	    }
	    @Transactional
	    public String updateDistributor(Distributor newDistributor)
	    {
	    	Distributor distributor = Ddao.findById(newDistributor.getDistributorId()).get();
	    	if(distributor!=null)
	    	{
	    	  distributor.setDistributorId(newDistributor.getDistributorId());
	    	  distributor.setDistributorName(newDistributor.getDistributorName());
	    	  distributor.setPhoneno(newDistributor.getPhoneno());
	    	  distributor.setAddress(newDistributor.getAddress());
	    	  return "Distributor Modified";
	    	}
	    	return "Update Failed";
	    }
}
