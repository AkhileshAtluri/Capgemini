package com.cg.anurag.b4.ims.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.anurag.b4.ims.dao.ProductOrdersDAO;
import com.cg.anurag.b4.ims.dto.ProductOrders;

@Service

public class ProductOrdersService 
{
	@Autowired
	ProductOrdersDAO pdodao;

	public void setPdodao(ProductOrdersDAO pdodao) {
		this.pdodao = pdodao;
	}
	@Transactional
	public ProductOrders addProduct(ProductOrders newpd)
	{
		return pdodao.save(newpd);
	}
	@Transactional
	public ProductOrders udpdateStatus(ProductOrders pd)
	{
		return pdodao.save(pd);
	}
	@Transactional
	public Optional<ProductOrders> getOrder(int orderId)
	{
		return pdodao.findById(orderId);
	}
	@Transactional
	public List<ProductOrders> getAllDetails()
	{
		return pdodao.findAll();
	}
	public String deleteOrder(int orderId)
	{
		pdodao.deleteById(orderId);
		return "Successfuly Deleted";
	}
}
