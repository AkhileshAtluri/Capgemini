package com.cg.anurag.b4.ims;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductOrdersApplicationTests {

	@Test
	void contextLoads() {
	}

}
