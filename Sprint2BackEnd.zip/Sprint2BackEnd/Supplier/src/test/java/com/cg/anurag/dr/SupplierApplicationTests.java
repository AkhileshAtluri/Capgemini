package com.cg.anurag.dr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupplierApplicationTests {

	@Test
	void contextLoads() {
	}

}
