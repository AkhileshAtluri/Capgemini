package com.cg.anurag.b4.ims.login.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.anurag.b4.ims.login.dto.Login;

@Repository
public interface LoginDao extends JpaRepository<Login,Long>
{

}
