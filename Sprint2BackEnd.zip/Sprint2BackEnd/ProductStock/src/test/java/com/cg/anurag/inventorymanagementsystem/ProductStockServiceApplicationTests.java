package com.cg.anurag.inventorymanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductStockServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
