package com.cg.anurag.b4.ims;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cg.anurag.b4.ims.dto.RawMaterialOrders;

@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
class RawMaterialOrdersApplicationTests {

	/*@Test
	void contextLoads() {
	}*/
	@Autowired
	TestRestTemplate testRestTemplate;
	public void setTestRestTemplate(TestRestTemplate testRestTemplate)
	{
		this.testRestTemplate=testRestTemplate;
	}
	
	@LocalServerPort
	int localServerPort;
	
	@Test
	public void testAddRawmaterialDetails_Positive() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"addRawMaterial";
		 RawMaterialOrders rmo = new RawMaterialOrders();
		 ResponseEntity<String> response = testRestTemplate.postForEntity(url,rmo,String.class);
		 Assertions.assertEquals(200, response.getStatusCodeValue());
	}
	
	@Test
	public void testAddRawMaterialDetails_Negative() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"addBook";
		 RawMaterialOrders rmo = null;
		 ResponseEntity<String> response = testRestTemplate.postForEntity(url,rmo,String.class);
		 Assertions.assertEquals(404, response.getStatusCodeValue());
	}

	@Test
	public void testGetOrder_Positive() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"getOrderDetails/63";
		 ResponseEntity<RawMaterialOrders> rmo = testRestTemplate.getForEntity(url,RawMaterialOrders.class);
		 Assertions.assertEquals(200,rmo.getStatusCodeValue());
	}
	
	@Test
	public void testGetOrder_Negative() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"getOrderDetails/163";
		 ResponseEntity<RawMaterialOrders> rmo = testRestTemplate.getForEntity(url,RawMaterialOrders.class);
		 Assertions.assertEquals(404,rmo.getStatusCodeValue());
	}
	
	@Test
	public void testDeleteOrder_Positive() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"deleteOrder/123456";
		  ResponseEntity<String> response = testRestTemplate.exchange(url,HttpMethod.DELETE,null,String.class);
		 Assertions.assertEquals(200, response.getStatusCodeValue());
	}
	
	@Test
	public void testDeleteOrder_Negative() throws Exception
	{
		 String url="http://localhost:"+localServerPort+"deleteOrder/1000";
		  ResponseEntity<String> response = testRestTemplate.exchange(url,HttpMethod.DELETE,null,String.class);
		 Assertions.assertEquals(404, response.getStatusCodeValue());
	}
}
