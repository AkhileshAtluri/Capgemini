package com.cg.anurag.b4.ims.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.anurag.b4.ims.dto.Supplier;

public interface SupplierDAO extends JpaRepository<Supplier, Integer>
{

}
