package com.cg.anurag.b4.ims.dto;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="rawmaterials")
public class RawMaterials 
{
	@Id
	@Column(name="rawmaterialid")
	int rawMaterialId;
	@Column(name="rawmaterialname")
	String rawMaterialName;
	@Column(name="priceperunit")
	int pricePerUnit;
	@Column(name="rawmaterialdesc")
	String description;
	@Column(name="warehouseid")
	int wareHouseId;
	@Column(name="supplierid")
	int supplierId;
	@Column(name="manufacturingdate")
	LocalDate manufacturingDate;
	@Column(name="expirydate")
	LocalDate expiryDate;
	public RawMaterials() {}
	public RawMaterials(int rawMaterialId, String rawMaterialName, int pricePerUnit, String description, int wareHouseId,
			int supplierId, LocalDate manufacturingDate, LocalDate expiryDate) {
		super();
		this.rawMaterialId = rawMaterialId;
		this.rawMaterialName = rawMaterialName;
		this.pricePerUnit = pricePerUnit;
		this.description = description;
		this.wareHouseId = wareHouseId;
		this.supplierId = supplierId;
		this.manufacturingDate = manufacturingDate;
		this.expiryDate = expiryDate;
	}
	
	public int getRawMaterialId() {
		return rawMaterialId;
	}
	public void setRawMaterialId(int rawMaterialId) {
		this.rawMaterialId = rawMaterialId;
	}
	public String getRawMaterialName() {
		return rawMaterialName;
	}
	public void setRawMaterialName(String rawMaterialName) {
		this.rawMaterialName = rawMaterialName;
	}
	public int getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(int pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getWareHouseId() {
		return wareHouseId;
	}
	public void setWareHouseId(int wareHouseId) {
		this.wareHouseId = wareHouseId;
	}
	public int getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}
	public LocalDate getManufacturingDate() {
		return manufacturingDate;
	}
	public void setManufacturingDate(LocalDate manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}
	public LocalDate getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}
	
}
