package com.cg.anurag.b4.ims.exceptions;

public class SupplierIdNotAvailableException extends RuntimeException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SupplierIdNotAvailableException()
	{
		super("Suplier With Requested ID Not Available");
	}
}
