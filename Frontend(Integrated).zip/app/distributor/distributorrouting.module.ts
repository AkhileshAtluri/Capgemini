import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';

import { DistributorListComponent } from './distributor-list.component';

import { DistributorComponent } from './distributor-component';


const routes: Routes = [{path:'alldistributors',component:DistributorListComponent},

                        {path:'distributor',component:DistributorComponent}
                       ];


@NgModule({

  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule]
})

export class DistributorRoutingModule { }
