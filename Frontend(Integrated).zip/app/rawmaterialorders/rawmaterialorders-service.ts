import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RawMaterialOrders } from './rawmaterialorders';
import { RawMaterials } from './rawmaterials';
import { Injectable } from '@angular/core';
@Injectable({
   providedIn:'root'
})
export class RawMaterialOrdersService
{
    public constructor(private httpClient:HttpClient){}

    public getRawMaterialOrder(orderId:number) : Observable<RawMaterialOrders>
    {
        return this.httpClient.get<any>('http://localhost:8037/getOrderDetails/'+orderId);
    }
    
    public getAllOrders() : Observable<RawMaterialOrders[]>
    {
	return this.httpClient.get<RawMaterialOrders[]>('http://localhost:8037/getAllOrders');
    }

    public updateRawMaterialOrder(rawMaterialOrder:RawMaterialOrders) : any
    {
	return this.httpClient.post<any>('http://localhost:8037/updateDeliveryStatus',rawMaterialOrder);
    }
    
    public addRawMaterialOrder(rawMaterialOrder:RawMaterialOrders)
    {
	return this.httpClient.post<any>('http://localhost:8037/addRawMaterial',rawMaterialOrder);
    }

    public deleteRawMaterialOrder(orderId:number) : any
    {
	return this.httpClient.delete<any>('http://localhost:8037/deleteOrder/'+orderId);
    }
    public getRawMaterialsList() : Observable<RawMaterials[]>
    {
	return this.httpClient.get<RawMaterials[]>('http://localhost:8037/getRawMaterialsList');
    }
}