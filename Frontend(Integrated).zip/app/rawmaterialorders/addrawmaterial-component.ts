import { Component, OnInit } from '@angular/core';
import { RawMaterialOrdersService } from './rawmaterialorders-service';
import { RawMaterialOrders } from './rawmaterialorders';
import { RawMaterials } from './rawmaterials';

@Component
({
	selector : 'addrawmaterial',
	templateUrl : './addrawmaterial-component.html'
})
export class AddRawMaterialComponent implements OnInit
{
    rawMaterialOrders:RawMaterialOrders = new RawMaterialOrders(0,null,0,0,0,null,"","","");
    public constructor(private rawMaterialOrdersService:RawMaterialOrdersService){}
    public addRawMaterialOrder() : void
    {
	this.rawMaterialOrdersService.addRawMaterialOrder(this.rawMaterialOrders).subscribe();
    }
     rawMaterials : RawMaterials[];
     flag:Boolean = false;
     public getRawMaterialsList() : void
	{
	    this.rawMaterialOrdersService.getRawMaterialsList().subscribe(data => this.rawMaterials = data);
	    this.flag = true;
        } 

    ngOnInit(){}
}