import { Component, OnInit } from '@angular/core';
import { RawMaterialOrdersService } from './rawmaterialorders-service';
import { RawMaterialOrders } from './rawmaterialorders';

@Component
({
	selector : 'deleterawmaterial',
	templateUrl : './deleteorder-component.html'
})
export class DeleteOrderComponent implements OnInit
{
     rawMaterialOrders:RawMaterialOrders = new RawMaterialOrders(0,null,0,0,0,null,"","","");
     public constructor(private rawMaterialOrdersService:RawMaterialOrdersService){}
     public deleteRawMaterialOrder() : void
    {
       
	this.rawMaterialOrdersService.deleteRawMaterialOrder(this.rawMaterialOrders.orderId).subscribe();
    }

    ngOnInit(){}
}