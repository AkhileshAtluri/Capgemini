import { Component, OnInit } from '@angular/core';
@Component
({
	selector : 'homepage',
	templateUrl : './homepage-component.html'
})
export class HomePageComponent implements OnInit
{
    ngOnInit(){}
}