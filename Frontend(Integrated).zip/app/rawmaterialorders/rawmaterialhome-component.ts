import { Component, OnInit } from '@angular/core';
@Component
({
	selector : 'rawmaterialhome',
	templateUrl : './rawmaterialhome-component.html'
})
export class RawMaterialHomeComponent implements OnInit
{
    ngOnInit(){}
}