import { Component, OnInit } from '@angular/core';
import { RawMaterialOrdersService } from './rawmaterialorders-service';
import { RawMaterialOrders } from './rawmaterialorders';

@Component
({
	selector : 'displayrawmaterial',
	templateUrl : './displayorder-component.html'
})
export class DisplayOrderComponent implements OnInit
{
     flag:Boolean = false;
     rawMaterialOrders:RawMaterialOrders = new RawMaterialOrders(0,null,0,0,0,null,"","","");
     public constructor(private rawMaterialOrdersService:RawMaterialOrdersService){}
    public getRawMaterialOrder():void
    {
	this.rawMaterialOrdersService.getRawMaterialOrder(this.rawMaterialOrders.orderId).subscribe(data => this.rawMaterialOrders = data );
        this.flag = true;
    }

    ngOnInit(){}
}