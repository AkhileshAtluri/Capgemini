import { Component, OnInit } from '@angular/core';
@Component({
 selector : 'au-supplier',
 templateUrl : './supplierhome.component.html',
})
export class SupplierHomeComponent implements OnInit
{
    ngOnInit(){}
}