import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';

import { SupplierListComponent } from './supplier-list.component';

import { SupplierComponent } from './supplier-component';


const routes: Routes = [{path:'allsupplier',component:SupplierListComponent},

                        {path:'supplier',component:SupplierComponent}

                       ];


@NgModule({

  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule]
})

export class SupplierRoutingModule { }
