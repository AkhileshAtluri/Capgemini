import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';

import { RawMaterialHomeComponent } from './rawmaterialorders/rawmaterialhome-component';
import { ProductStockComponent } from './productstock/productstock.component';
import { RawMaterialStockComponent } from './rawmaterialstock/rawmaterialstock.component';
import { ProductHomeComponent } from './productorders/producthome.component';
import { DistributorHomeComponent } from './distributor/distributorhome.component';
import { SupplierHomeComponent } from './supplier/supplierhome.component';
const routes: Routes = [
			{path:'rawmaterialsop',component:RawMaterialHomeComponent},
			{path:'productstockop',component:ProductStockComponent},
			{path:'rawmaterialstockop',component:RawMaterialStockComponent},
			{path:'productsop',component:ProductHomeComponent},
			{path:'distributorop',component:DistributorHomeComponent},
			{path:'supplierop',component:SupplierHomeComponent}
		      ];


@NgModule
({

  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule]

})

export class AppRoutingModule { }
