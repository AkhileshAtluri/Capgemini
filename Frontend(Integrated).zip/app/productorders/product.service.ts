import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  constructor(private httpService: HttpClient) {}

 public getProducts() : Observable<Product[]>
  {
     return this.httpService.get<Product[]>('http://localhost:8090/getProducts');
  }
} 


