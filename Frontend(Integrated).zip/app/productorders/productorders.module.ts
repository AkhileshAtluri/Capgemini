import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; 
import { CommonModule } from '@angular/common';
import { ProductOrdersService } from './productorders.service';
import { ProductOrdersComponent } from './productorders.component';
import { ProductOrdersRoutingModule } from './productordersrouting.module';
import { ProductComponent } from './product.component';
import { ProductHomeComponent } from './producthome.component';
@NgModule({
  
   declarations: [
 ProductOrdersComponent, ProductComponent, ProductHomeComponent  ],
 
   imports: [
 ProductOrdersRoutingModule,  HttpClientModule, FormsModule , CommonModule ],
  
   providers: [ ProductOrdersService ],
 
   exports: [ ProductOrdersComponent, ProductComponent, ProductHomeComponent ]
})
export class ProductOrdersModule
{
}