import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';

import { ProductHomeComponent } from './producthome.component';
import { ProductComponent } from './product.component';
import { ProductOrdersComponent } from './productorders.component';
const routes: Routes = [
			{path:'product',component:ProductComponent},
			{path:'productorder',component:ProductOrdersComponent}		         
];


@NgModule
({

  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule]

})

export class ProductOrdersRoutingModule { }
