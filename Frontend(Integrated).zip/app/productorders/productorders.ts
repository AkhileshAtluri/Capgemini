export class ProductOrders
{
    orderId:number;
   productName:String;
    pricePerUnit:number;
    quantityValue:number;
    totalPrice:number;
    wareHouseId:number;
    supplierId:number;
    deliveryDate:String;
    manufacturingDate:String;
    expiryDate:String;
    deliveryStatus:String;
    public constructor(orderId:number, productName:String, pricePerUnit:number, quantityValue:number, totalPrice:number,wareHouseId:number,
		       supplierId:number, deliveryDate:String, manufacturingDate:String, expiryDate:String, deliveryStatus:String)
    {
	this.orderId = orderId;
	this.productName = productName;
	this.pricePerUnit = pricePerUnit;
	this.quantityValue = quantityValue;
	this.totalPrice = totalPrice;
	this.wareHouseId = wareHouseId;
	this.supplierId = supplierId;
	this.deliveryDate = deliveryDate;
	this.manufacturingDate = manufacturingDate;
	this.expiryDate = expiryDate;
	this.deliveryStatus = deliveryStatus;
    }
}