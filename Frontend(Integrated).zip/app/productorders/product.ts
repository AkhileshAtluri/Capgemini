export class Product
{
    productId:number;
    productName:string;
    productWeight:string;
    productPrice:number;
    manufacturingDate:String;
    expiryDate:String;
    public constructor(productId:number,productName:string,productWeight:string,productPrice:number,manufacturingDate:String,
        expiryDate:String)
    {
        this.productId=productId;   
        this.productName = productName;
        this.productWeight = productWeight;   
        this.productPrice = productPrice;
        this.manufacturingDate=manufacturingDate;
        this.expiryDate=expiryDate;
    }
}
 