import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';

import { ProductOrders } from './productorders';

import { ProductOrdersService } from './productorders.service';


@Component({

  selector: 'app-productorder',

  templateUrl: './productorders.component.html',

  styleUrls: ['./productorder.component.css']

})

export class ProductOrdersComponent implements OnInit 
{

  users1:ProductOrders[];

  message:string;

  orderId:number;

  constructor(private route: ActivatedRoute,private router:Router,
    private productOrdersService: ProductOrdersService
    )
 { }

  ngOnInit()
 {

    this.orderId=0;

  }


   public list1()
{

    this.productOrdersService.placeorder(this.orderId)
.subscribe(users1 => {this.users1= users1},error=>{this.message="ProductId does not exist"}
    );
}

onSubmit() {
  this.list1();
}


}
