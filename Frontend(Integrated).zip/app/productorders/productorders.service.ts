import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ProductOrders } from './productorders';

@Injectable({
  providedIn: 'root'
})
export class ProductOrdersService {
  constructor(private httpService: HttpClient) {}

  public placeorder(orderId:number) : Observable<ProductOrders[]>
  {
     return this.httpService.get<ProductOrders[]>('http://localhost:8090/getProduct/'+orderId);
  }
} 


