import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';


import { Product } from './product';

import { ProductOrders } from './productorders';

import { ProductService } from './product.service';


@Component({

  selector: 'app-product',

  templateUrl: './product.component.html',

  styleUrls: ['./product.component.css']

})

export class ProductComponent implements OnInit 
{


  constructor(private route: ActivatedRoute,private router:Router,
    private productService: ProductService
    )
 { }

users:Product[];

users1:ProductOrders[];

message:string;

orderId:number;

  ngOnInit(): void
 {
  }


  list()
{

    this.productService.getProducts().subscribe(data => {this.users= data;},error => console.log(error));
  }
/*
   list1(){
    this.wireService.placeorder(this.orderId)
    .subscribe(users1 => {this.users1= users1;
      this.router.navigate(['product/order']);
      error=>{this.message="Account does not exists"}
    });
}

*/

}

