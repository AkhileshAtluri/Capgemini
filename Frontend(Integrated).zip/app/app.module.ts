import { BrowserModule } from '@angular/platform-browser';

import { NgModule } from '@angular/core';


import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; 
import { CommonModule } from '@angular/common';
import { RawMaterialOrdersModule } from './rawmaterialorders/rawmaterialorders.module';
import { ProductStockModule } from './productstock/productstock.module';
import { RawMaterialStockModule } from './rawmaterialstock/rawmaterialstock.module';


import { ProductOrdersModule } from './productorders/productorders.module';
import { DistributorModule } from './distributor/distributor.module';
import { SupplierModule } from './supplier/supplier.module';
@NgModule({

  declarations: [
    AppComponent
  ],

  imports: [

    BrowserModule,
 AppRoutingModule, HttpClientModule, FormsModule , CommonModule,RawMaterialOrdersModule,
		ProductStockModule, RawMaterialStockModule, ProductOrdersModule, DistributorModule, SupplierModule ],

  providers: [],

  bootstrap: [AppComponent]

})

export class AppModule { }
