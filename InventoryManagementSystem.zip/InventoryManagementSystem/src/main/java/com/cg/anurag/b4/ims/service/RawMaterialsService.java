package com.cg.anurag.b4.ims.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.anurag.b4.ims.dao.RawMaterialsDAO;
import com.cg.anurag.b4.ims.dto.RawMaterials;

@Service
public class RawMaterialsService 
{
	@Autowired
	RawMaterialsDAO rmdao;
	public void setRmdao(RawMaterialsDAO rmdao) 
	{
		this.rmdao = rmdao;
	}
	
	@Transactional
	public List<RawMaterials> getRawMaterialsList()
	{
		return rmdao.findAll();
	}
}
