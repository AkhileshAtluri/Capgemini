import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RawMaterials } from './rawmaterials';
import { Injectable } from '@angular/core';
@Injectable({
   providedIn:'root'
})
export class RawMaterialsService
{
    public constructor(private httpClient:HttpClient){}

    public getRawMaterialsList() : Observable<RawMaterials[]>
    {
	return this.httpClient.get<RawMaterials[]>('http://localhost:8037/getRawMaterialsList');
    }
}