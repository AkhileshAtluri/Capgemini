import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; 
import { CommonModule } from '@angular/common';
import { RawMaterialsService } from './rawmaterials-service';
import { RawMaterialsComponent } from './rawmaterials-component';

@NgModule({
  
   declarations: [
  RawMaterialsComponent,   ],
 
   imports: [
    HttpClientModule, FormsModule , CommonModule ],
  
   providers: [ RawMaterialsService ],
 
   exports: [ RawMaterialsComponent ]
})
export class RawMaterialsModule
{
}