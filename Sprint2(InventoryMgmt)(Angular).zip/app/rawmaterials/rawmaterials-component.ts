import { Component, OnInit } from '@angular/core';
import { RawMaterialsService } from './rawmaterials-service';
import { RawMaterials } from './rawmaterials';
@Component({
	selector : 'rawmaterials-list',
	templateUrl : './rawmaterials-component.html'
})
export class RawMaterialsComponent implements OnInit
{
    rawMaterials : RawMaterials[];
     public constructor(private rawMaterialsService:RawMaterialsService){}

     public getRawMaterialsList() : void
	{
	    this.rawMaterialsService.getRawMaterialsList().subscribe(data => this.rawMaterials = data);
	} 

    ngOnInit(){}
}