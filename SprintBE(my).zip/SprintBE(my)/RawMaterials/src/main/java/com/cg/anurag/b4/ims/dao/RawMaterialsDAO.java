package com.cg.anurag.b4.ims.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.anurag.b4.ims.dto.RawMaterials;

public interface RawMaterialsDAO extends JpaRepository<RawMaterials, Integer>
{

}
