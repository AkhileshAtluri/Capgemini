package com.cg.anurag.b4.ims.service;

import java.time.LocalDate;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.anurag.b4.ims.dto.RawMaterialOrders;
import com.cg.anurag.b4.ims.dto.RawMaterials;
import com.cg.anurag.b4.ims.dto.Supplier;


@SpringBootTest
public class TestRawMaterialOrdersService 
{
	@Autowired
	RawMaterialOrdersService rmoService;
	
	@Test
    public void testGetDetails_Positive() throws Exception
    {
  	    Optional<RawMaterialOrders> book = rmoService.getDetails(62);
  	    Assertions.assertEquals(true,book.isPresent());
    }
    
    @Test
    public void testGetDetails_Negative() throws Exception
    {
  	    Optional<RawMaterialOrders> book = rmoService.getDetails(100);
  	    Assertions.assertEquals(false,book.isPresent());
    }
	
	@Test
	public void testDeleteOrder_Positive() throws Exception
	{
		String s = rmoService.deleteOrder(100);
		Assertions.assertEquals("Sucessfully Deleted",s);
	}
	
	@Test
	public void testDeleteOrder_Negative() throws Exception
	{
		String s = rmoService.deleteOrder(2345);
		Assertions.assertEquals("Sucessfully Deleted",s);
	}
	
	 @Test
     public void testAddRawMaterial_Positive() throws Exception
     {
		  RawMaterials rawMaterials = new RawMaterials(1,"RawMaterial1",100,"100gms",501,101,LocalDate.parse("2020-03-20"),LocalDate.parse("2020-12-20"));
		  Supplier s = new Supplier(102,"Rupendra",1122334455,"CHE");
     	  RawMaterialOrders rmo = new RawMaterialOrders(0,rawMaterials,2,200,501,s,LocalDate.now(),LocalDate.now().plusDays(10),"Processing");
    	  RawMaterialOrders r = rmoService.addRawmaterial(rmo);
    	  Assertions.assertEquals(r.getOrderId(), rmo.getOrderId());
     }
	 @Test
	 public void testAddRawMaterial_Negative() throws Exception
	 {
		 RawMaterialOrders rmo = null;
		 RawMaterialOrders r = rmoService.addRawmaterial(rmo);
		 Assertions.assertEquals(null, rmo);
	 }
}
