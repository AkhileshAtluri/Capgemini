package com.cg.anurag.b4.ims.exceptions;

public class OrderIdNotFoundException extends RuntimeException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OrderIdNotFoundException()
	{
		super("Order Id Does Not Exist");
	}
}
