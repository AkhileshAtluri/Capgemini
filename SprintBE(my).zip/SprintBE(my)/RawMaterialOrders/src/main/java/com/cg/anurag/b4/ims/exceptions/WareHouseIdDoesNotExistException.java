package com.cg.anurag.b4.ims.exceptions;

public class WareHouseIdDoesNotExistException extends RuntimeException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WareHouseIdDoesNotExistException()
	{
		super("WareHouse ID Does Not Exist");
	}
}
