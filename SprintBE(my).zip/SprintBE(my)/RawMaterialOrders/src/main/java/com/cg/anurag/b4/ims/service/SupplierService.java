package com.cg.anurag.b4.ims.service;

import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.anurag.b4.ims.dao.SupplierDAO;
import com.cg.anurag.b4.ims.dto.Supplier;

@Service
public class SupplierService 
{
	@Autowired
	SupplierDAO sdao;
	public void setSdao(SupplierDAO sdao) 
	{
		this.sdao = sdao;
	}
	
	@Transactional
	public Optional<Supplier> getSupplier(int supplierId)
	{
		return sdao.findById(supplierId);
	}
}
