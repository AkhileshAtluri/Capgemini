package com.cg.anurag.b4.ims.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.anurag.b4.ims.dto.RawMaterialOrders;
import com.cg.anurag.b4.ims.dto.RawMaterials;
import com.cg.anurag.b4.ims.dto.Supplier;
import com.cg.anurag.b4.ims.service.RawMaterialOrdersService;
import com.cg.anurag.b4.ims.service.RawMaterialsService;
import com.cg.anurag.b4.ims.service.SupplierService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class RawMaterialOrdersController 
{
	@Autowired
	RawMaterialOrdersService rmoService;
	public void setRmoService(RawMaterialOrdersService rmoService) 
	{
		this.rmoService = rmoService;
	}
	@Autowired
	SupplierService ss;
	
	public void setSs(SupplierService ss) 
	{
		this.ss = ss;
	}
	@Autowired
	RawMaterialsService rms;
	
	public void setRms(RawMaterialsService rms) {
		this.rms = rms;
	}
    @Autowired 
    RestTemplate restTemplate;
    public void setRestTemplate(RestTemplate restTemplate)
    {
    	this.restTemplate = restTemplate;
    }
    
	@GetMapping(value="/getAllOrders")
	public List<RawMaterialOrders> getAllOrders()
	{
		return rmoService.getAllDetails();
	}
	
	@GetMapping(value = "/getOrderDetails/{orderId}")
	public ResponseEntity<Optional<RawMaterialOrders>> getOrder(@PathVariable int orderId)
	{
		Optional<RawMaterialOrders> rawMaterial = rmoService.getDetails(orderId);
		if(rawMaterial.isPresent())
			return new ResponseEntity<Optional<RawMaterialOrders>>(rawMaterial,HttpStatus.OK);
		return new ResponseEntity<Optional<RawMaterialOrders>>(rawMaterial,HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping("/deleteOrder/{orderId}")
	public ResponseEntity<String> deleteOrder(@PathVariable int orderId)
	{
		try
		{
			rmoService.deleteOrder(orderId);
			return new ResponseEntity<String>("Deleted Successfully",HttpStatus.OK);
		}
		catch(Exception ex)
		{
			return new ResponseEntity<String>("Deletion Failed",HttpStatus.NOT_FOUND);
		}
	}
	@PostMapping(value="/addRawMaterial",consumes="application/json")
    public ResponseEntity<String> addRawMaterialDetails(@RequestBody() RawMaterialOrders rm)
    {
  	  try
  	  {
  		  String d= "processing";
  		  RawMaterials raw = rms.getRawMaterialById(rm.getRawMaterials().getRawMaterialId());
  		  Supplier supplier = ss.getSupplier(rm.getSupplier().getSupplierId()).get();
  		  if(raw!=null && supplier!=null)
  		  {
  		    rm.setTotalPrice(raw.getPricePerUnit()* rm.getQuantityValue());
  		    rm.setDateOfOrder(LocalDate.now());
  		    rm.setDeliveryDate(LocalDate.now().plusDays(10));
  		    rm.setDeliveryStatus(d);
  	        rmoService.addRawmaterial(rm);
  	      return new ResponseEntity<String>("RawMaterial Added",HttpStatus.OK);
  		  }
  		  else
  			return new ResponseEntity<String>("Failed",HttpStatus.NOT_FOUND);
  	  }
  	  catch(Exception ex)
  	  {
  	    	return new ResponseEntity<String>(ex.getMessage()+" Insertion Failed",HttpStatus.BAD_REQUEST);
  	  } 
    }
    
	@PostMapping(value="/updateDeliveryStatus",consumes="application/json")
    public ResponseEntity<String> updateDeliveryStatus(@RequestBody() RawMaterialOrders rm)
    {
  	  try
  	  {
  		    rmoService.addRawmaterial(rm);
  	      return new ResponseEntity<String>("Succesfully Updated",HttpStatus.OK);
  	  }
  	  catch(Exception ex)
  	  {
  	    	return new ResponseEntity<String>(ex.getMessage()+" Updation Failed",HttpStatus.BAD_REQUEST);
  	  } 
    }
	@GetMapping(value = "/getRawMaterialsList")
	public List<RawMaterials> getAllList()
	{
		return rms.getRawMaterialsList();
	}
	
	
    
    /*@GetMapping(value = "/getRawBySupplier/{supplierId}")
    public Optional<RawMaterialOrders> getRawBySupplier(@PathVariable int supplierId)
    {
    	//Supplier s = restTemplate.exchange("http://supplier-service/getSupplierDetails/{supplierId}",HttpMethod.GET,null,Supplier.class,supplierId).getBody();
    	Supplier s = restTemplate.getForEntity("http://supplier-service/getSupplierDetails/"+supplierId,Supplier.class).getBody();
    	return rmoService.getRMOBySupplierId(s);
    }*/

}
