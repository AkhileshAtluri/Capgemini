package com.cg.anurag.b4.ims.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.anurag.b4.ims.dto.RawMaterialOrders;
import com.cg.anurag.b4.ims.dto.Supplier;

public interface RawMaterialOrdersDAO extends JpaRepository<RawMaterialOrders, Integer> 
{
	public Optional<RawMaterialOrders> findBySupplier(Supplier s);
	
}
