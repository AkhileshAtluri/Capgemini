package com.cg.anurag.b4.ims.exceptions;

public class RawMaterialNotAvailableException extends RuntimeException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RawMaterialNotAvailableException()
	{
		super("Raw Material Not Available");
	}
}
