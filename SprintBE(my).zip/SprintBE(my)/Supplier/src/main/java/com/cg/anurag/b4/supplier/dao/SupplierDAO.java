package com.cg.anurag.b4.supplier.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.anurag.b4.supplier.dto.Supplier;
@Repository
public interface SupplierDAO extends JpaRepository<Supplier,Integer> {

}
