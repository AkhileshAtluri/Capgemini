package com.cg.anurag.b4.supplier.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.anurag.b4.supplier.dto.Supplier;
import com.cg.anurag.b4.supplier.service.SupplierService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class SupplierController {
	 @Autowired
		SupplierService  supplierService;
		public void setSupplierService(SupplierService supplierService)
		{
			this.supplierService=supplierService;
		}
		
	   @GetMapping(value = "/getSupplier/{supplierId}")
	   public Supplier getSupplier(@PathVariable int supplierId)
	   {
		   return supplierService.getSupplier(supplierId);
	   }
	   
	   @GetMapping(value = "/getSuppliers")
	   public List<Supplier> getSupplier()
	   {
		   return supplierService.getSupplier();
	   }
	   @PostMapping(value="/addSupplier",consumes="application/json")
	   public ResponseEntity<String> insertSupplier(@RequestBody()Supplier supplier)
	   {
		   String message="Supplier Inserted Successfully";
		   if(supplierService.insertSupplier(supplier)==null)
			   message="Supplier Insertion Failed";
		   return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
	   }
	   
	   @PutMapping(value="/updateSupplier",consumes="application/json")
	   public String updateSupplier(@RequestBody()Supplier supplier)
	   {
		   String message=supplierService.updateSupplier(supplier);
		   return message;
	   }
}

	