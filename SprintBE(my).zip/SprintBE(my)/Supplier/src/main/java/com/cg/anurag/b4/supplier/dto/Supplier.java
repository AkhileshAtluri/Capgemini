package com.cg.anurag.b4.supplier.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Supplier {
	@Id	
	   @Column(name="supplierid")
	   int supplierId;
	   @Column(name="supplier_name")
	   String supplierName;
	   @Column(name="phoneno")
	   long phoneNumber;
	   @Column(name="address")
	   String address;
	   public Supplier() {}
	   public Supplier(int supplierId, String supplierName, long phoneNumber, String address) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}
	public int getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	   
}
