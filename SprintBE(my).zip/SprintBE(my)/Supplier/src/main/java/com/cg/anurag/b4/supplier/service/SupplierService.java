package com.cg.anurag.b4.supplier.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.anurag.b4.supplier.dao.SupplierDAO;
import com.cg.anurag.b4.supplier.dto.Supplier;
@Service
public class SupplierService {
	@Autowired
    SupplierDAO Sdao;
    public void setSdao(SupplierDAO sdao) { this.Sdao=sdao;}
    @Transactional
    public Supplier insertSupplier(Supplier supplier)
    {
        return Sdao.save(supplier);
    }
    @Transactional(readOnly=true)
    public Supplier getSupplier(int supplierId)
    {
    	return Sdao.findById(supplierId).get();
    }
    @Transactional(readOnly=true)
    public List<Supplier> getSupplier()
    {
    	return Sdao.findAll();
    }
    @Transactional
    public String updateSupplier(Supplier newSupplier)
    {
    	Supplier supplier= Sdao.findById(newSupplier.getSupplierId()).get();
    	if(supplier!=null)
    	{
    	  supplier.setSupplierId(newSupplier.getSupplierId());
    	  supplier.setSupplierName(newSupplier.getSupplierName());
    	  supplier.setPhoneNumber(newSupplier.getPhoneNumber());
    	  supplier.setAddress(newSupplier.getAddress());
    	  return "Supplier Modified";
    	}
    	return "Update Failed";
    }
}
