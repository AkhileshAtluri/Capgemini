package com.cg.anurag.b4.ims.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.anurag.b4.ims.dao.RawMaterialOrdersDAO;
import com.cg.anurag.b4.ims.dto.RawMaterialOrders;

@Service
public class RawMaterialOrdersService 
{
	@Autowired
	RawMaterialOrdersDAO rmodao;
	public void setRmodao(RawMaterialOrdersDAO rmodao) 
	{
		this.rmodao = rmodao;
	}
	
	public RawMaterialOrders addRawmaterial(RawMaterialOrders newrm)
	{
		return rmodao.save(newrm);
	}
	@Transactional
	public Optional<RawMaterialOrders> getDetails(int orderId)
	{
		return rmodao.findById(orderId);
	}
	@Transactional
	public List<RawMaterialOrders> getAllDetails()
	{
		return rmodao.findAll();
	}
	@Transactional
	public String deleteOrder(int orderId)
	{
		 rmodao.deleteById(orderId);
		 return "Sucessfully Deleted";
	}

    @Transactional
    public RawMaterialOrders updateStatus(RawMaterialOrders newRawMaterial)
    {
	   return rmodao.save(newRawMaterial);
   }
}
