package com.cg.anurag.b4.ims.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.anurag.b4.ims.dto.Products;
import com.cg.anurag.b4.ims.service.ProductsService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ProductsController 
{
	@Autowired
	ProductsService pds;
		
	public void setPds(ProductsService pds) {
		this.pds = pds;
	}


	@GetMapping(value = "/getProductsList")
	public List<Products> getAllList()
	{
		return pds.getProductsList();
	}
	
}
