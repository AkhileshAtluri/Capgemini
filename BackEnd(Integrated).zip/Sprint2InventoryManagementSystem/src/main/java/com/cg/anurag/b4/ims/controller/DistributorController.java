package com.cg.anurag.b4.ims.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.cg.anurag.b4.ims.dto.Distributor;
import com.cg.anurag.b4.ims.service.DistributorService;

@RestController
public class DistributorController 
{
    @Autowired
	DistributorService  distributorService;
	public void setDistributorService(DistributorService distributorService)
	{
		this.distributorService=distributorService;
	}
	
   @GetMapping("/getDistributor/{distributorId}")
   public Distributor getDistributor(@PathVariable int distributorId)
   {
	   return distributorService.getDistributor(distributorId);
   }
   
   @GetMapping("/getDistributors")
   public List<Distributor> getDistributor()
   {
	   return distributorService.getDistributor();
   }
}
