package com.cg.anurag.b4.ims.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.anurag.b4.ims.dao.RawMaterialStockDAO;
import com.cg.anurag.b4.ims.dto.RawMaterialStock;
@Service
public class RawMaterialStockService {
	@Autowired
	RawMaterialStockDAO rmsdao;
	public void setRmsdao(RawMaterialStockDAO rmsdao) { this.rmsdao=rmsdao;}
	 @Transactional
	public RawMaterialStock addStock(RawMaterialStock rawMaterialStock)
	 {
		 return rmsdao.save(rawMaterialStock);
	 }
		 
}
