package com.cg.anurag.b4.ims.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.anurag.b4.ims.dao.ProductStockDAO;
import com.cg.anurag.b4.ims.dto.ProductStock;

@Service
public class ProductStockService {
	@Autowired
    ProductStockDAO psdao;
	public void setPsdao(ProductStockDAO psdao) { this.psdao=psdao;}
	 @Transactional
	    public ProductStock addStock(ProductStock productStock)
	    {
		 return psdao.save(productStock);
	    }
	 
	 	
	 

}
