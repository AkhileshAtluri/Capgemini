package com.cg.anurag.b4.ims.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.anurag.b4.ims.dto.Products;

public interface ProductsDAO extends JpaRepository<Products, Integer>
{

}
