package com.cg.anurag.b4.ims;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprint2InventoryManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sprint2InventoryManagementSystemApplication.class, args);
	}

}
