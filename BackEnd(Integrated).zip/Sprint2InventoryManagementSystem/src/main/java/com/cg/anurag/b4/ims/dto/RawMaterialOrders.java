package com.cg.anurag.b4.ims.dto;

import java.time.LocalDate;
//import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="rawmaterialorders")
public class RawMaterialOrders 
{
	@Id
	@Column(name="orderid")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="MYSEQ")
	@SequenceGenerator(name="MYSEQ",sequenceName = "rmorderid",allocationSize=1)
	int orderId;
	@OneToOne
	@JoinColumn(name="rawmaterialid")
	RawMaterials rawMaterials;
	@Column(name="quantityvalue")
	double quantityValue;
	@Column(name="totalprice")
	double totalPrice;
	@Column(name="warehouseid")
	int wareHouseId;
	@OneToOne
	@JoinColumn(name="supplierid")
	Supplier supplier;
	@Column(name="dateoforder")
	LocalDate dateOfOrder;
	@Column(name="deliverydate")
	LocalDate deliveryDate;
	@Column(name="deliverystatus")
	String deliveryStatus;
	public RawMaterialOrders() {}
	public RawMaterialOrders(int orderId, RawMaterials rawMaterials, double quantityValue, double totalPrice,
			int wareHouseId, Supplier supplier, LocalDate dateOfOrder, LocalDate deliveryDate, String deliveryStatus) {
		super();
		this.orderId = orderId;
		this.rawMaterials = rawMaterials;
		this.quantityValue = quantityValue;
		this.totalPrice = totalPrice;
		this.wareHouseId = wareHouseId;
		this.supplier = supplier;
		this.dateOfOrder = dateOfOrder;
		this.deliveryDate = deliveryDate;
		this.deliveryStatus = deliveryStatus;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	
	public RawMaterials getRawMaterials() {
		return rawMaterials;
	}
	public void setRawMaterials(RawMaterials rawMaterials) {
		this.rawMaterials = rawMaterials;
	}
	public double getQuantityValue() {
		return quantityValue;
	}
	public void setQuantityValue(double quantityValue) {
		this.quantityValue = quantityValue;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getWareHouseId() {
		return wareHouseId;
	}
	public void setWareHouseId(int wareHouseId) {
		this.wareHouseId = wareHouseId;
	}
	
	public Supplier getSupplier() {
		return supplier;
	}
	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	public LocalDate getDateOfOrder() {
		return dateOfOrder;
	}
	public void setDateOfOrder(LocalDate dateOfOrder) {
		this.dateOfOrder = dateOfOrder;
	}
	public LocalDate getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(LocalDate deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	
}
