package com.cg.anurag.b4.ims.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.anurag.b4.ims.dto.Distributor;
import com.cg.anurag.b4.ims.dto.ProductOrders;
import com.cg.anurag.b4.ims.dto.Products;
import com.cg.anurag.b4.ims.service.DistributorService;
import com.cg.anurag.b4.ims.service.ProductOrdersService;
import com.cg.anurag.b4.ims.service.ProductsService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ProductOrdersController 
{
	@Autowired
	ProductOrdersService pdoService;
	public void setPdoService(ProductOrdersService PdoService) 
	{
		this.pdoService = PdoService;
	}
	@Autowired
	DistributorService ds;
	
	public void setDs(DistributorService ds) {
		this.ds = ds;
	}
	@Autowired
	ProductsService pds;
	
	public void setRms(ProductsService pds) {
		this.pds = pds;
	}

	@GetMapping(value="/getproductAllOrders")
	public List<ProductOrders> getAllOrders()
	{
		return pdoService.getAllDetails();
	}
	
	@GetMapping(value = "/getProductOrderDetails/{orderId}")
	public ResponseEntity<Optional<ProductOrders>> getOrder(@PathVariable int orderId)
	{
		Optional<ProductOrders> rawMaterial = pdoService.getOrder(orderId);
		if(rawMaterial.isPresent())
			return new ResponseEntity<Optional<ProductOrders>>(rawMaterial,HttpStatus.OK);
		return new ResponseEntity<Optional<ProductOrders>>(rawMaterial,HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping("/deleteProductOrder/{orderId}")
	public ResponseEntity<String> deleteOrder(@PathVariable int orderId)
	{
		try
		{
			pdoService.deleteOrder(orderId);
			return new ResponseEntity<String>("Deleted Successfully",HttpStatus.OK);
		}
		catch(Exception ex)
		{
			return new ResponseEntity<String>("Deletion Failed",HttpStatus.BAD_REQUEST);
		}
	}
	@PostMapping(value="/addProduct",consumes="application/json")
    public ResponseEntity<String> addRawMaterialDetails(@RequestBody() ProductOrders pdo)
    {
  	  try
  	  {
  		  String d= "processing";
  		  Products p = pds.getProductById(pdo.getProducts().getProductId());
  		  Distributor dt = ds.getDistributor(pdo.getDistributor().getDistributorId());
  		  if(p!=null && dt!=null)
  		  {
  		    pdo.setTotalPrice(p.getPricePerUnit()* pdo.getQuantityValue());
  		    pdo.setDateOfOrder(LocalDate.now());
  		    pdo.setDeliveryDate(LocalDate.now().plusDays(10));
  		    pdo.setDeliveryStatus(d);
  	        pdoService.addProduct(pdo);
  	      return new ResponseEntity<String>("RawMaterial Added",HttpStatus.OK);
  		  }
  		  else
  			return new ResponseEntity<String>("Failed",HttpStatus.NOT_FOUND);
  	  }
  	  catch(Exception ex)
  	  {
  	    	return new ResponseEntity<String>(ex.getMessage()+" Insertion Failed",HttpStatus.BAD_REQUEST);
  	  } 
    }
    
	@PostMapping(value="/updateproductDeliveryStatus",consumes="application/json")
    public ResponseEntity<String> updateDeliveryStatus(@RequestBody() ProductOrders pdo)
    {
  	  try
  	  {
  		  Products p = pds.getProductById(pdo.getProducts().getProductId());
  		   Distributor d = ds.getDistributor(pdo.getDistributor().getDistributorId());
  		  if(p!=null && d!=null)
  		  {
  		    pdoService.udpdateStatus(pdo);
  	      return new ResponseEntity<String>("Succesfully Updated",HttpStatus.OK);
  		  }
  		  else
  			return new ResponseEntity<String>("Updation Failed",HttpStatus.NOT_FOUND);
  	  }
  	  catch(Exception ex)
  	  {
  	    	return new ResponseEntity<String>(ex.getMessage()+" Updation Failed",HttpStatus.BAD_REQUEST);
  	  } 
    }
    
   }
