package com.cg.anurag.b4.ims.dto;

import java.time.LocalDate;
//import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="productorders")
public class ProductOrders 
{
	@Id
	@Column(name="orderid")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="MY_SEQ")
	@SequenceGenerator(name="MY_SEQ",sequenceName = "pdorderid",allocationSize=1)
	int orderId;
	@OneToOne
	@JoinColumn(name="productid")
	Products products;
	@Column(name="quantityvalue")
	int quantityValue;
	@Column(name="totalprice")
	int totalPrice;
	@Column(name="warehouseid")
	int wareHouseId;
	@OneToOne
	@JoinColumn(name="distributorid")
	Distributor distributor;
	@Column(name="dateoforder")
	LocalDate dateOfOrder;
	@Column(name="deliverydate")
	LocalDate deliveryDate;
	@Column(name="deliverystatus")
	String deliveryStatus;
	public ProductOrders() {}
	public ProductOrders(int orderId, Products products, int quantityValue, int totalPrice, int wareHouseId,
			Distributor distributor, LocalDate dateOfOrder, LocalDate deliveryDate, String deliveryStatus) {
		super();
		this.orderId = orderId;
		this.products = products;
		this.quantityValue = quantityValue;
		this.totalPrice = totalPrice;
		this.wareHouseId = wareHouseId;
		this.distributor = distributor;
		this.dateOfOrder = dateOfOrder;
		this.deliveryDate = deliveryDate;
		this.deliveryStatus = deliveryStatus;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Products getProducts() {
		return products;
	}
	public void setProducts(Products products) {
		this.products = products;
	}
	public int getQuantityValue() {
		return quantityValue;
	}
	public void setQuantityValue(int quantityValue) {
		this.quantityValue = quantityValue;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getWareHouseId() {
		return wareHouseId;
	}
	public void setWareHouseId(int wareHouseId) {
		this.wareHouseId = wareHouseId;
	}
	public Distributor getDistributor() {
		return distributor;
	}
	public void setDistributor(Distributor distributor) {
		this.distributor = distributor;
	}
	public LocalDate getDateOfOrder() {
		return dateOfOrder;
	}
	public void setDateOfOrder(LocalDate dateOfOrder) {
		this.dateOfOrder = dateOfOrder;
	}
	public LocalDate getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(LocalDate deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	
}