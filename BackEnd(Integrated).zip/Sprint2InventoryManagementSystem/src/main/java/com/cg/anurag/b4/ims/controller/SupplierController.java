package com.cg.anurag.b4.ims.controller;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.cg.anurag.b4.ims.dto.Supplier;
import com.cg.anurag.b4.ims.service.SupplierService;

@RestController
public class SupplierController 
{
	@Autowired
	SupplierService ss;
	public void setSs(SupplierService ss) 
	{
		this.ss = ss;
	}
	
	@GetMapping(value = "/getSupplierDetails/{supplierId}")
	public ResponseEntity<Optional<Supplier>> getSupplierDetails(@PathVariable int supplierId)
	{
		Optional<Supplier> supplier = ss.getSupplier(supplierId);
		if(supplier.isPresent())
			return new ResponseEntity<Optional<Supplier>>(supplier,HttpStatus.OK);
		return new ResponseEntity<Optional<Supplier>>(supplier,HttpStatus.NOT_FOUND);
	}
}
